//
//  ViewController.swift
//  lab2
//
//  Created by zhananhua on 2019/5/8.
//  Copyright © 2019 jinxin. All rights reserved.
//

import UIKit
var number = Int()
var result = [Int]()
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let length = 20
    @IBOutlet weak var input: UITextField!
    
    @IBOutlet weak var tableview: UITableView!
    
    @IBAction func okBtn(_ sender: Any) {
  

        number = Int(input.text!)!
        result = []
        for i in 0..<length{
           let a = Int(i) * number
            result.append(a)
        }
        
        self.tableview.reloadData()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return length
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        if number == Int(){
            cell.textLabel?.text = ""
        }else{
        cell.textLabel?.text = " \(String(number)) * \(indexPath.row) = \(String(result[indexPath.row])) "
        }
        
            return cell
 
     
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

