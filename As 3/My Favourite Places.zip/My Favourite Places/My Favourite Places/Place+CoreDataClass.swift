//
//  Place+CoreDataClass.swift
//  My Favourite Places
//
//  Created by 孙帆 on 11/05/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Place)
public class Place: NSManagedObject {

}
