//
//  ViewController.swift
//  My Favourite Places
//
//  Created by 孙帆 on 01/05/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//

import UIKit
import MapKit
import CoreData
var places = [Dictionary<String, String>()]
class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(places.count)
        // Do any additional setup after loading the view, typically from a nib.
        if currentPlace == -1 {
            let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
            let coordinate = CLLocationCoordinate2D(latitude: 53.406566, longitude: -2.966531)
            let region = MKCoordinateRegion(center: coordinate, span: span)
            self.map.setRegion(region, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "my Loaction"
            self.map.addAnnotation(annotation)
            let lpgr = UILongPressGestureRecognizer(target: self, action:
                #selector(ViewController.longpress(gestureRecognizer:)))
            lpgr.minimumPressDuration = 2
            map.addGestureRecognizer(lpgr)
            
        }
        guard currentPlace != -1 else { return }
        guard places.count > currentPlace else { return }
        guard let name = places[currentPlace]["name"] else { return }
        guard let lat = places[currentPlace]["lat"] else { return }
        guard let lon = places[currentPlace]["lon"] else { return }
        guard let latitude = Double(lat) else { return }
        guard let longitude = Double(lon) else { return }
        let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        self.map.setRegion(region, animated: true)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = name
        self.map.addAnnotation(annotation)
        print(currentPlace)
        let lpgr = UILongPressGestureRecognizer(target: self, action:
            #selector(ViewController.longpress(gestureRecognizer:)))
        lpgr.minimumPressDuration = 2
        map.addGestureRecognizer(lpgr)
        
      
    }
    @objc func longpress(gestureRecognizer: UIGestureRecognizer) {
        if gestureRecognizer.state == UIGestureRecognizer.State.began {
            print("===\nLong Press\n===")
            let touchPoint = gestureRecognizer.location(in: self.map)
            let newCoordinate = self.map.convert(touchPoint, toCoordinateFrom: self.map)
            print(newCoordinate)
            let location = CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude)
            var title = ""
            CLGeocoder().reverseGeocodeLocation(location, completionHandler: { (placemarks, error) in
                if error != nil {
                    print(error!)
                } else {
                    if let placemark = placemarks?[0] {
                        if placemark.subThoroughfare != nil {
                            title += placemark.subThoroughfare! + " "
                        }
                        if placemark.thoroughfare != nil {
                            title += placemark.thoroughfare!
                        }
                    } }
                if title == "" {
                    title = "Added \(NSDate())"
                }
                let annotation = MKPointAnnotation()
                annotation.coordinate = newCoordinate
                annotation.title = title
                self.map.addAnnotation(annotation)
                places.append(["name":title, "lat": String(newCoordinate.latitude), "lon":
                    String(newCoordinate.longitude)])
                let place1 = Place(context: PersistenceService.context)
                place1.lat = newCoordinate.latitude
                place1.lon = newCoordinate.longitude
                place1.place = title
                PersistenceService.saveContext()
            })
            
        }
    }

   

}

