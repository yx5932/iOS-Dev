//
//  Place+CoreDataProperties.swift
//  My Favourite Places
//
//  Created by 孙帆 on 11/05/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//
//

import Foundation
import CoreData


extension Place {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Place> {
        return NSFetchRequest<Place>(entityName: "Place")
    }

    @NSManaged public var lat: Double
    @NSManaged public var lon: Double
    @NSManaged public var place: String?

}
