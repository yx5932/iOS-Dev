//
//  ViewController.swift
//  map
//
//  Created by zhananhua on 2019/3/28.
//  Copyright © 2019 zhananhua. All rights reserved.
//

import UIKit
import MapKit
import CoreData
 var items: [NSManagedObject] = []
var a: [Double] = []
class ViewController: UIViewController,MKMapViewDelegate {

    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        if currentPlace == -1 {
            let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
            let coordinate = CLLocationCoordinate2D(latitude: 53.406566, longitude: -2.966531)
            let region = MKCoordinateRegion(center: coordinate, span: span)
            self.map.setRegion(region, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "my Loaction"
            self.map.addAnnotation(annotation)
            for i in 0..<items.count{
                let coordinate = CLLocationCoordinate2D(latitude: items[i].value(forKey: "lat")! as! CLLocationDegrees, longitude: items[i].value(forKey: "lon")! as! CLLocationDegrees)
                let annotation = MKPointAnnotation()
                annotation.coordinate = coordinate
                self.map.addAnnotation(annotation)
            }
            
            let lpgr = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.longpress(guestureRecognizer:)))
            lpgr.minimumPressDuration = 2
            map.addGestureRecognizer(lpgr)
            
        }
        
        
        
        guard currentPlace != -1 else { return }
       
        guard  let name = items[currentPlace].value(forKey: "place") as? String else {
            return
        }
        
        let lats = items[currentPlace].value(forKey: "lat")!
        let lons = items[currentPlace].value(forKey: "lon")!
        
        
        
      
        let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
        let coordinate = CLLocationCoordinate2D(latitude: lats as! CLLocationDegrees, longitude: lons as! CLLocationDegrees)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        self.map.setRegion(region, animated: true)

        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = name
        self.map.addAnnotation(annotation)
        
        print(annotation.title!)
        print(annotation.coordinate)
        
        let lpgr = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.longpress(guestureRecognizer:)))
        lpgr.minimumPressDuration = 2
        map.addGestureRecognizer(lpgr)
        
        }
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let context = appDelegate!.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Item")

        do{
            items = try context.fetch(fetchRequest)
        } catch {
            print("fail")
        }
    }
    
    func save(_ place: String,_ lat: Double,_ lon: Double ){
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let context = appDelegate!.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Item", in: context)!
        let item = NSManagedObject(entity: entity, insertInto: context)
        
        item.setValue(place, forKey:"place")
        item.setValue(lat, forKey: "lat")
        item.setValue(lon, forKey: "lon")
        do{
            try context.save()
           items.append(item)
            
        } catch {
            print("fail")
        }
    }
    
    @objc func longpress(guestureRecognizer: UIGestureRecognizer){
        if guestureRecognizer.state == UIGestureRecognizer.State.began{
            print("long press")
            let touchPoint = guestureRecognizer.location(in: self.map)
            let newCoordinate = self.map.convert(touchPoint, toCoordinateFrom: self.map)
            print(newCoordinate)

            let location = CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude)
            var title = ""
            CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) in
                if error != nil {
                    print(error!)

                }else{
                    if let placemarks = placemarks?[0]{
                        if placemarks.subThoroughfare != nil{
                            title += placemarks.subThoroughfare! + " "
                        }
                        if placemarks.thoroughfare != nil {
                            title += placemarks.thoroughfare!
                        }
                    }
                }
                if title == " "{
                    title = "Added  \(NSDate())"
                }
                let annotation = MKPointAnnotation()
                annotation.coordinate = newCoordinate
                annotation.title = title
                self.map.addAnnotation(annotation)
                self.save(title,newCoordinate.latitude,newCoordinate.longitude)
                place.append(["name": title, "lat": String(newCoordinate.latitude), "lon":String(newCoordinate.longitude)])
            })

        }
    }
  
}

