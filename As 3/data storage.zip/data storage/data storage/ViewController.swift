//
//  ViewController.swift
//  data storage
//
//  Created by zhananhua on 2019/3/29.
//  Copyright © 2019 jinxin. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var items: [NSManagedObject] = []
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row].value(forKeyPath: "itemName") as? String
        return cell
    }
    

    @IBOutlet weak var item: UITextField!
    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let context = appDelegate!.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Item")
        
        do{
            items = try context.fetch(fetchRequest)
        } catch {
            print("fail")
        }
    }
    
    @IBAction func add(_ sender: Any) {
        let itemtoadd = item.text!
        save(itemtoadd)
        self.tableview.reloadData()
    }
    
    func save(_ itemName: String){
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let context = appDelegate!.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Item", in: context)!
        let item = NSManagedObject(entity: entity, insertInto: context)
        
    
  
        
        item.setValue(itemName, forKey:"itemName")
        
        do{
            try context.save()
                items.append(item)
            
        } catch {
            print("fail")
        }
    }
    
}

