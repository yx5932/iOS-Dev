//
//  Items+CoreDataClass.swift
//  Shopping List
//
//  Created by Xin.Yan on 2019/5/6.
//  Copyright © 2019 Yan Xin. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Items)
public class Items: NSManagedObject {

}
