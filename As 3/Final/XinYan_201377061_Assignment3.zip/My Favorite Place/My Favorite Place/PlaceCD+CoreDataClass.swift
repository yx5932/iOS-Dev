//
//  PlaceCD+CoreDataClass.swift
//  My Favorite Place
//
//  Created by Xin.Yan on 2019/5/10.
//  Copyright © 2019 Yan Xin. All rights reserved.
//
//

import Foundation
import CoreData

@objc(PlaceCD)
public class PlaceCD: NSManagedObject {

}
