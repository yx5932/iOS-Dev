//
//  ViewController.swift
//  Interface Builder(Task 5)
//
//  Created by Yan, Xin [sgxyan2] on 10/05/2019.
//  Copyright © 2019 Yan, Xin [sgxyan2]. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

