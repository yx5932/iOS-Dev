//
//  Item+CoreDataProperties.swift
//  ShoppingList
//
//  Created by 孙帆 on 30/04/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var name: String?

}
