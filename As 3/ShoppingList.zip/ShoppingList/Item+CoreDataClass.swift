//
//  Item+CoreDataClass.swift
//  ShoppingList
//
//  Created by 孙帆 on 30/04/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
