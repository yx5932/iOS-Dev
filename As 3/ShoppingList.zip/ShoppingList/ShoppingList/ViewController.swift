//
//  ViewController.swift
//  ShoppingList
//
//  Created by 孙帆 on 30/04/2019.
//  Copyright © 2019 孙帆. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var item = [Item]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let fetchRequest: NSFetchRequest<Item> = Item.fetchRequest()
        do{
           let item = try CoreDataManager.context.fetch(fetchRequest)
            self.item = item
        }
        catch{}
    }
  
    @IBOutlet weak var itemName: UITextField!
    var context: NSManagedObjectContext?
    @IBAction func add(_ sender: AnyObject) {
//            let newItem = NSEntityDescription.insertNewObject(forEntityName: "Item", into: context!) as! Item
//        do {
//            try context?.save()
//
//            print("Saved")
//
//        } catch {
//            print("there was an error")
//        }
        
        let item = Item(context: CoreDataManager.context)
        item.name = itemName.text
        CoreDataManager.saveContext()
        self.item.append(item)
        self.tableView.reloadData()
    }
   
}

extension ViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = item[indexPath.row].name
        return cell
    }
}
